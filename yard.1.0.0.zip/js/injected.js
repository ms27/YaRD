var YaRDer = {
	author:{"en":"Magomedov Said",
			"ru":"Магомедов Саид"},
	email:"linpark1999@gmail.com",
	vk:"//vk.com/id266788473",
	name:"Yandex.Radio downloader",
	shortName:"YaRDer",
	description:{"ru":"Скачивание играющих песен со страниц Яндекс.Радио",
				"en":"Downloading music from Yandex.Radio"},
	version:"0.0.1",
	license:"MIT license",
	init:function(){
		$('body').attr('data-yard-status', 'disable');

		// внедряю кнопку для скачивания на странице Я.Музыка
		if(location.host.indexOf('music.yandex.ru') + 1){
			$('.sidebar').append('<div class="YaRD_zone"><div class="button button_transparent YaRD_download_button"><span class="button__label">Cкачать трек</span></div></div>');
		// внедряю кнопку для скачивания на странице Я.Радио
		} else {
			$('.head__content').append('<div class="button button_transparent YaRD_download_button"><span class="button__label">Cкачать трек</span></div>');
		}

		var last_played = ['id песни', 'Название исполнителя', 'Название песни'],
			status = [0, 0]; // [0] = 0: нет ничего, 1: есть что-то; [1] = 1: приостановлено, 2: играет сейчас

		// функция для скачивания файла. track - объект, с данными о текущей песни
		this.download = function(track, callback){
			// можно что-то скачать
			if (status[0]){
				// создаю ссылку для скачивания песни и вызываю её
				var link = document.createElement("a"),
					name = track.title + ' - ' + track.artists[0].name;
				link.href = track.src;
				link.download = name;
				link.click();

				// обратная связь. [0] = скачка пошла; [1] = название скачиваемой песни
				callback(true, name);
			} else {
				// обратная связь. [0] = скачать не получилось;
				callback(false);
			}
		};
		// редактирование статуса возможности скачивания и состояния кнопки скачивания
		this.e_status = function(player){
			// объект с данными о текущем треке
			var track = player.getCurrentTrack();
			// ничего не проигрывается
			if (track == null){
				// деактивирую кнопку для скачивания
				$('body').attr('data-yard-status', 'disable');
				// изменяю текущий статус
				status = [0, 0];
			// что-то играет, но проигрывание приостановлено
			} else if (track.id && player.isPlaying() == false){
				$('body').attr('data-yard-status', 'visible-hidden');
				status = [1, 1];
			// что-то играет прямо сейчас
			} else {
				$('body').attr('data-yard-status', 'visible');
				status = [1, 2];
			}
			// что-то играет
			if (track != null){
				last_played = [player.getCurrentTrack().id, track.artists[0].name, track.title];
			}
		};

		// возвращение значений:
		this.rt = function(v){
			switch (v) {
				// проигрываемый трек
				case 'last_played':
					return last_played
				// текущий статус
				case 'status':
					return status
				// это нафиг не нужно, но оставлю всё равно, ради прикола
				default:
					return false
			}
		};
	}
}
var YaRD = new YaRDer.init();

$(document).ready(function(){
	var player = Mu.blocks.di.repo.player,
		button = $('.YaRD_download_button');
	// кто-то нажал на кнопку. супер-расширение уже спешит на помощь
	$('.YaRD_download_button').click(function(){
		// пытаюсь скачать файл. [0] = данные о треке; [1] = ответ: [1][0] = 0 - песня не скачалась, 1 - всё чётко; [1][1] = название скачиваемой песни
		YaRD.download(player.getCurrentTrack(), function(status, name){
			// скачивается
			if(status){
				console.log('Скачивается песня: ' + name);
				$('[data-yard-wait]').attr('data-yard-wait', '')
				setTimeout(function(){
					$('.YaRD_download_button').removeAttr('data-yard-wait');
				}, 3000);
			// решил не скачивать песню
			} else {
				console.log('Что-то случилось, песня не скачалась :(');
			}
		});
	});
	// чекаю текущий статус и изменяю его. изменяю title у кнопки
	setInterval(function(){
		YaRD.e_status(player);

		var last = YaRD.rt('last_played');
		$('.YaRD_download_button').attr('data-yard-track', last[2] + ' - ' + last[1]);
	}, 250);
});