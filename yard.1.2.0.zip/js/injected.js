var YaRDer = {
	author:{"en":"Magomedov Said",
			"ru":"Магомедов Саид"},
	email:"linpark1999@gmail.com",
	vk:"//vk.com/id266788473",
	name:"Yandex.Radio downloader",
	shortName:"YaRD",
	description:{"ru":"Скачивание играющих песен со страниц Яндекс.Радио и Яндекс.Музыка",
				"en":"Downloading music from Yandex.Radio and Yandex.Music"},
	license:"MIT license",
	init:function(){
		$('body').attr('data-yard-status', 'disable');

		// внедряю кнопку для скачивания на странице Я.Музыка
		if(location.host.indexOf('music.yandex.ru') + 1){
			$('.sidebar').append('<div class="YaRD_zone"><div class="button button_transparent YaRD_download_button"><span class="button__label">Cкачать трек</span></div></div>');
		// внедряю кнопку для скачивания на странице Я.Радио
		} else {
			$('.head__content').append('<div class="YaRD_on_radio">'+
											'<div class="button button_transparent YaRD_download_button">'+
												'<span class="button__label">Cкачать трек</span>'+
											'</div>'+
											'<div class="YaRD_lyrics_button button button_transparent button_ico" title="Текст песни">'+
												'<span class="icon"></span>'+
											'</div>'+
										'</div>');
			$('.centerblock').append('<div class="YaRD_lyrics" data-yard-lyrics-status="loading">'+
										'<div class="YaRD_lyrics__close"><span class="YaRD_lyrics__close_button popup__close icon icon_size_L icon_remove"></span></div>'+
										'<header class="YaRD_lyrics__header" >'+
											'<p class="YaRD_lyrics__title">Текст песни</p>'+
											'<p class="YaRD_lyrics__song_name">Подождите…</p>'+
											'<p class="YaRD_lyrics__artist_name">Загружается песня</p>'+
										'</header>'+
										'<div class="YaRD_lyrics__text">Скоро заиграет песня<br>И появится текст к ней</div>'+
										'<footer class="YaRD_lyrics__footer">'+
											'<p class="YaRD_lyrics__song_name"></p>'+
											'<p class="YaRD_lyrics__artist_name"></p>'+
										'</footer>'+
										'<div class="YaRD_lyrics__bottom">Слушайте музыку на Яндекс.Радио</div>'+
									'</div>');
		}

		var last_played = ['id песни', 'Название исполнителя', 'Название песни'],
			status = [0, 0]; // [0] = 0: нет ничего, 1: есть что-то; [1] = 1: приостановлено, 2: играет сейчас

		// функция для скачивания файла. track - объект, с данными о текущей песни
		this.download = function(track, callback){
			// можно что-то скачать
			if (status[0]){
				// создаю ссылку для скачивания песни и вызываю её
				var link = document.createElement("a"),
					name = track.title + ' - ' + track.artists[0].name,
					src = 'http://playground.magomedov-said.ru/extensions/YaRD/download/?src=http:' + track.src + '&name=' + name + '.' + track.format.codec;
				link.href = src;
				// link.download = name;
				// link.target = "_blank";
				link.click();
				delete link;

				// обратная связь. [0] = скачка пошла; [1] = название скачиваемой песни
				callback(true, name);
			} else {
				// обратная связь. [0] = скачать не получилось;
				callback(false);
			}
		};
		// редактирование статуса возможности скачивания и состояния кнопки скачивания
		this.e_status = function(player){
			// объект с данными о текущем треке
			var track = player.getCurrentTrack();
			// ничего не проигрывается
			if (track == null){
				// деактивирую кнопку для скачивания
				$('body').attr('data-yard-status', 'disable');
				// изменяю текущий статус
				status = [0, 0];
			// что-то играет, но проигрывание приостановлено
			} else if (track.id && player.isPlaying() == false){
				$('body').attr('data-yard-status', 'visible-hidden');
				status = [1, 1];
			// что-то играет прямо сейчас
			} else {
				$('body').attr('data-yard-status', 'visible');
				status = [1, 2];
			}
			// что-то играет
			if (track != null){
				last_played = [track.id, track.artists[0].name, track.title];
			}
		};

		// подготавливаю полное название трека по своему шаблону, стандарту
		this.rt_track_name = function(song, artist){
			if (song && artist){
				return song + ' - ' + artist;
			} else {
				return last_played[2] + ' - ' + last_played[1];
			}
		}
		// запрос на обновление текта
		this.update_lyrics = function(player){
			// показываю, что занят поисками
			this.e_lyrics_content('loading','…','Загрузка…','Подождите, пожалуйста');

			// узнаю, а есть ли вообще у трека текст
			if(player.getCurrentTrack().lyricsAvailable){
				// похоже, что есть. ну что, пытаюсь его откопать
				window.postMessage({
					lyrics: last_played[0],
					source: 'YaRD'
				}, '*');

				// заношу в дневник информацию о том, что этот текст у меня имеется, его, пока-что, больше заказывать не нужно
				var last = YaRD.rt('last_played')
					last_title = last[2] + ' - ' + last[1];
					$('.YaRD_lyrics_button').attr('data-yard-last-lyrics', last_title);
			// а если у текста нет текста, то зачем его искать?
			} else {
				// смотрю, подгружал ли я текст ранее, если да, то значит должен быть старый АйДи, он является числом
				if($.isNumeric(last_played[0])){
					// оповещаю юзера о том, что не подгружу текст
					this.e_lyrics_content('not-found',
						'Текст к песне отсутствует<br><br>Либо его просто нет в базе<br>Во всём виновата Яндекс.Музыка',
						'Не нашёл :(','Такое бывает…');
				}
			}
			need_lyrics = true;
		}
		var need_lyrics = false;
		this.e_need_lyrics = function(b){
			if (b)
				need_lyrics = true;
		}
		// обновление блока с текстом песни
		this.e_lyrics_content = function(status, text, song, artist){
			if (status)
				$('.YaRD_lyrics').attr('data-yard-lyrics-status', status);
			else
				$('.YaRD_lyrics').removeAttr('data-yard-lyrics-status');
			$('.YaRD_lyrics__text').html(text);
			if (song)
				$('.YaRD_lyrics__song_name').html(song);
			else
				$('.YaRD_lyrics__song_name').html(last_played[2]);
			if (song)
				$('.YaRD_lyrics__artist_name').html(artist);
			else
				$('.YaRD_lyrics__artist_name').html(last_played[1]);
		}

		// возвращение значений:
		this.rt = function(v){
			switch (v) {
				// проигрываемый трек
				case 'last_played':
					return last_played
				// текущий статус
				case 'status':
					return status
				case 'need_lyrics':
					return need_lyrics
				// это нафиг не нужно, но оставлю всё равно, ради прикола
				default:
					return false
			}
		};
	}
}
var YaRD = new YaRDer.init();

$(document).ready(function(){
	var player = Mu.blocks.di.repo.player,
		button = $('.YaRD_download_button');
	// кто-то нажал на кнопку. супер-расширение уже спешит на помощь
	$(button).click(function(){
		// пытаюсь скачать файл. [0] = данные о треке; [1] = ответ: [1][0] = 0 - песня не скачалась, 1 - всё чётко; [1][1] = название скачиваемой песни
		YaRD.download(player.getCurrentTrack(), function(status, name){
			// скачивается
			if(status){
				console.log('Скачивается песня: ' + name);
				// показываю, что что-то произошло, скачивание началось
				$(button).attr('data-yard-wait', '');
				// убираю оповещение о начале скачки, юзеру должно хватить данного времени, чтобы понять, что я хотел сказать. а если он не успел, то он слишком глуп
				setTimeout(function(){
					$(button).removeAttr('data-yard-wait');
				}, 3000);
			// решил не скачивать песню
			} else {
				console.log('Что-то случилось, песня не скачалась :(');
			}
		});
	});
	// чекаю текущий статус и изменяю его. изменяю title у кнопки
	setInterval(function(){
		YaRD.e_status(player);

		var last_title = YaRD.rt_track_name();
		$(button).attr('data-yard-track', last_title);

		// 
		var c_need_update = YaRD.rt('need_lyrics');
		if(player.getCurrentTrack() != null){
			if (c_need_update && $('.YaRD_lyrics_button').attr('data-yard-last-lyrics') != last_title && $('[data-yard-lyrics]').length > 0){
				YaRD.update_lyrics(player);
			}
		} else {
			YaRD.e_need_lyrics(1);
			YaRD.e_lyrics_content('failed', 'Почему-то отсутствуют данные о треке<br>Проверьте своё подключение к сети<br>Возможно, проблема именно в этом<br>А значит, я не смогу работать с текстом :)', 'Ошибка 8(');
		}
	}, 250);

	// кто-то захотел узнать текст играющей песни
	$('.YaRD_lyrics_button').click(function(){
		// ну что ж, открою специальное окно
		$('body').attr('data-yard-lyrics', '');

		// проверяю, нужно ли обновлять поля
		var last = YaRD.rt('last_played')
			last_title = YaRD.rt_track_name();
		// похоже, что всё таки нужно
		if ($('.YaRD_lyrics_button').attr('data-yard-last-lyrics') != last_title){
			YaRD.update_lyrics(player);
		}
	});
	// скрываю блок с лирикой по просьбе юзера
	$('.YaRD_lyrics__close_button, .logo__service, .head__stations').click(function(){
		$('body').removeAttr('data-yard-lyrics');
	});
	// появления дополнительного название у блока с текстом песни, при исчезновении основного
	$('.YaRD_lyrics').scroll(function(){
		if($(this).scrollTop() > $('.YaRD_lyrics__header').outerHeight()){
			$('.YaRD_download_button').addClass('m--hover');
		} else {
			$('.YaRD_download_button').removeClass('m--hover');
		}
	});
	// чекаю входящие
	window.addEventListener('message', function(event){
		var message = event.data;
		// проверяю, мне ли они адресованы
		// если да, то смотрю, что внутри
		if (message.source == 'YaRD_res'){
			// я заказывал текст песни, ничего другого не жду, поэтому сразы выпендриваюсь, показываю его юзеру
			YaRD.e_lyrics_content(false, message.lyrics[0].fullLyrics.replace(/[\n]/g, '<br>'));
		}
	});
});