$.get(chrome.extension.getURL('templates/lyric-block.html'), 
	function(data) {
		data = data.replace(/__MSG_(\w+)__/g, function(match, v1){
				return v1 ? chrome.i18n.getMessage(v1) : "";
			});
		$('.centerblock').append(data);
		
		$.get(chrome.extension.getURL('js/injected.js'), 
			function(data) {
				var script = document.createElement("script");
				script.setAttribute("type", "text/javascript");
				script.innerHTML = data;
				document.getElementsByTagName("head")[0].appendChild(script);
			}
		);
	}
);
//download.js v3.0, by dandavis; 2008-2014. [CCBY2] see http://danml.com/download.html for tests/usage
function download(data,strFileName,strMimeType){var self=window,u="application/octet-stream",m=strMimeType||u,x=data,D=document,a=D.createElement("a"); /* <мои изменения> */ a.target = "_blank";/* </мои изменения> */var z=function(a){return String(a)},B=self.Blob||self.MozBlob||self.WebKitBlob||z,BB=self.MSBlobBuilder||self.WebKitBlobBuilder||self.BlobBuilder,fn=strFileName||"download",blob,b,ua,fr;if(String(this)==="true"){x=[x,m];m=x[0];x=x[1]}if(String(x).match(/^data\:[\w+\-]+\/[\w+\-]+[,;]/)){return navigator.msSaveBlob?navigator.msSaveBlob(d2b(x),fn):saver(x)}try{blob=x instanceof B?x:new B([x],{type:m})}catch(y){if(BB){b=new BB();b.append([x]);blob=b.getBlob(m)}}function d2b(u){var p=u.split(/[:;,]/),t=p[1],dec=p[2]=="base64"?atob:decodeURIComponent,bin=dec(p.pop()),mx=bin.length,i=0,uia=new Uint8Array(mx);for(i;i<mx;++i)uia[i]=bin.charCodeAt(i);return new B([uia],{type:t})}function saver(url,winMode){if('download'in a){a.href=url;a.setAttribute("download",fn);a.innerHTML="downloading...";D.body.appendChild(a);setTimeout(function(){a.click();D.body.removeChild(a);if(winMode===true){setTimeout(function(){self.URL.revokeObjectURL(a.href)},250)}},66);return true}var f=D.createElement("iframe");D.body.appendChild(f);if(!winMode){url="data:"+url.replace(/^data:([\w\/\-\+]+)/,u)}f.src=url;setTimeout(function(){D.body.removeChild(f)},333)}if(navigator.msSaveBlob){return navigator.msSaveBlob(blob,fn)}if(self.URL){saver(self.URL.createObjectURL(blob),true)}else{if(typeof blob==="string"||blob.constructor===z){try{return saver("data:"+m+";base64,"+self.btoa(blob))}catch(y){return saver("data:"+m+","+encodeURIComponent(blob))}}fr=new FileReader();fr.onload=function(e){saver(this.result)};fr.readAsDataURL(blob)}return true}


window.addEventListener('message', function(event) {
	// Only accept messages from the same frame
	if (event.source != window) {
		return;
	}

	var message = event.data;

	// Only accept messages that we know are ours
	if (message.source == 'YaRD') {
		if (message.need_to_know){
			var link = 'https://music.yandex.ru/handlers/track.jsx?track='+message.need_to_know;

			$.ajax(link)
				.done(function(r) {
					console.info("Нашёл инфу о треке " + r.track.title + " и текст этой самой песни:", r);
					if (r.lyric){
						window.postMessage({
							res: r,
							source: 'YaRD_res'
						}, '*');
					}
				})
				.fail(function(){
					window.postMessage({
						res: false,
						source: 'YaRD_res'
					}, '*');
					console.error('YaRD •--• Не нашёл дополнительную инфу о треке ' + r.track.title + '. Значит, текст тоже не подгружу :(');
				});
		}
		else if (message.download){
			var x=new XMLHttpRequest();
				x.open("GET", message.download[0], true);
				x.responseType = 'blob';
				// x.onloadstart=function(){
				// 		window.postMessage({
				// 			download_res: 'started',
				// 			source: 'YaRD_res'
				// 		}, '*');
				// }
				x.onload=function(){
					download(x.response, message.download[1]+'.mp3', "audio/mpeg" );
					window.postMessage({
						download_res: 'finished',
						download_play_status: message.download[2],
						source: 'YaRD_res'
					}, '*');
				}
				x.send();
		}
		else if (message.news) {
			$.getJSON('https://ms27.github.io/YaRD/info.json?time=' + new Date().getTime(), function(){
				console.log('YaRD •--• Есть новости?');
				})
				.done(function(r) {
					console.log('YaRD •--• Есть новости!', r);
					if (r.output){
						window.postMessage({
							news_res: r.output,
							source: 'YaRD_res'
						}, '*');
					} else {
						window.postMessage({
							news_res: 'fail',
							source: 'YaRD_res'
						}, '*');
					}
				})
				.fail(function(){
						window.postMessage({
							news_res: 'fail',
							source: 'YaRD_res'
						}, '*');
					console.error('YaRD •--• Ошибка при получении ответа на вывод новостей.');
				});
		}
	}
});