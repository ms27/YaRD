// {
//   "output":
//     {
//       "title":"400 пользователей!",
//       "subtitle":"Ура! Но…",
//       "text":"Поддержка расширения скоро прекратится. Начиная с 27 мая, оно не будет больше обновляться. Сожалею об этом, но выбора нет.",
//       "subtext":"Причина: изменяющийся объект Mu (буду называть его API), с помощью которого получаются все данные для вывода. Нет полного контроля над ключами объекта, а это значит, что расширение может неожиданно перестать работать, хоть в коде нет ошибок.<br>Если Вы знакомы с JS, умеете работать с объектами в программировании и у Вас есть желание поддерживать расширение, то можете использовать исходники и продолжать поддерживание расширения в активном состоянии. Все содержимое файлов расширения, распространяется по MIT лицензии :)<br>Если появилось желание работы над расширением, напишите в поддержку:<a class='YaRD__news_button' href='https://chrome.google.com/webstore/detail/yandexradio-music-downloa/iipdlolanhldhhdjaiebciofkiejnold/support'>я готов!</a>"
//     }
// }

var YaRD__class = {
	author:"Магомедов Саид",
	email:"linpark1999@gmail.com",
	vk:"//vk.com/id266788473",
	name:"Yandex.Radio downloader",
	shortName:"YaRD",
	description:"Скачивание играющих песен со страниц Яндекс.Радио и Яндекс.Музыка",
	license:"MIT license",
	init: function(){
		$('body').attr('data-yard-status', 'disable');
		this.last_played = 0;
		this.status = [0, 0];						// [0] = 0: нет ничего, 1: есть что-то; [1] = 1: приостановлено, 2: играет сейчас
		this.video_list = [];
		// внедряю кнопку для скачивания на странице Я.Музыка
		if(location.host.indexOf('music.yandex.ru') + 1){
			$('.sidebar').append('<div class="YaRD_zone"><div class="button button_transparent YaRD_download_button"><span class="button__label">Cкачать трек</span></div></div>');
		// внедряю кнопку для скачивания на странице Я.Радио
		} else {
			$('.head__content').append('<div class="YaRD_on_radio">'+
											'<div class="button button_transparent YaRD_download_button">'+
												'<span class="button__label">Cкачать трек</span><span class="YaRD_loading_spin"></span>'+
											'</div>'+
											'<div class="YaRD_lyrics_button button button_transparent button_ico" title="Текст песни">'+
												'<span class="icon"></span>'+
											'</div>'+
										'</div>');
			$('body').prepend('<div class="YaRD_video__wrap"><div class="YaRD_video__close"></div><div class="YaRD_video__embed"></div></div>');
		}

		// лень писать цикл, пусть так будет
		$('[data-yard-version-name="instrumental"]').clone().appendTo('.t--YaRD_track_versions__output').attr('data-yard-version-name', 'live').find('.t--YaRD_track_versions__type_name').html('Live');
		$('[data-yard-version-name="instrumental"]').clone().appendTo('.t--YaRD_track_versions__output').attr('data-yard-version-name', 'remix').find('.t--YaRD_track_versions__type_name').html('Remix');
		$('[data-yard-version-name="instrumental"]').clone().appendTo('.t--YaRD_track_versions__output').attr('data-yard-version-name', 'another').find('.t--YaRD_track_versions__type_name').html('Другое');

		// функция для скачивания файла. track - объект, с данными о текущей песни
		// использую костыль. пробовал юзать встроенную функцию downloads, прописывал в премишионах разрешение на это, но чёт не получалось. пытался выполнять эту функцию в background.js, но у объекта chrome отсутсвует download. если вы это читаете и можете помочь в решении этой проблемы, свяжитесь со мной, пожалуйста. просто уже самому интересно, почему не выходит, ибо по документации делал.
		this.download = function(type, callback){
			var track;
			// if (Mu.blocks.di.repo.player.getTrack){
			// 	track = Mu.blocks.di.repo.player.getTrack();
			// } else if (Mu.blocks.di.repo.player.getTrack){
			// 	track = Mu.blocks.di.repo.player.getTrack();
			// }
			track = Mu.blocks.di.repo.player.getTrack();
			// можно что-то скачать
			if (this.status[0]){
				var link = document.createElement("a"),
					name = track.title + ' - ' + track.artists[0].name;
						
				if (type == 2){
					link.href = track._ey;
					link.download = name;
					link.click();
					delete link;
				} else {
					// создаю ссылку для скачивания песни и вызываю её
						if (Mu.authData.user.uid == 0)
							$('.player-controls__play').click();	// очередной костыль
						var src = track._ey || track._er;
						window.postMessage({
							download: ['https:'+ src, name, this.status[1]],
							source: 'YaRD'
						}, '*');

					// этот костыль уходит в архив:
					// var src = 'http://playground.magomedov-said.ru/extensions/YaRD/download/?src=http:' + track._ey + '&name=' + name + '.' + track.format.codec;
					// link.href = src;
					// link.click();
					// delete link;
				}
				// обратная связь. [0] = скачка пошла; [1] = название скачиваемой песни
				callback(true, name);
			} else {
				// обратная связь. [0] = скачать не получилось;
				callback(false);
			}
		};

		this.e_status = function(player){			// редактирование статуса возможности скачивания и состояния кнопки скачивания
			if (player == null || player == undefined){	// ничего не проигрывается
				$('body').attr('data-yard-status', 'disable'); // деактивирую кнопку для скачивания
				this.status = [0, 0];					// изменяю текущий статус
				this.last_played = 0;
				return false;
			} else if (player.id && Mu.blocks.di.repo.player.isPlaying() == false){ // что-то играет, но проигрывание приостановлено
				$('body').attr('data-yard-status', 'visible-hidden');
				this.status = [1, 1];
			} else {								// что-то играет прямо сейчас
				if (Mu.blocks.di.repo.player.getState() == 'playing'){
					$('body').attr('data-yard-status', 'visible');
					this.status = [1, 2];
				} else {
					this.status = [1, 1];
					$('body').attr('data-yard-status', 'visible-hidden');
				}
			}
			return true;
		};

		var checker;
		this.start_updating = function(stop){		// сообщаю о необходимости в проверке обновлений
			if (stop) {								// нужно остановить проверку
				clearInterval(checker);				// останавливаю
				return true;
			}										// не нужно останавливать проверку
			this.check_for_update(1);				// сразу же начинаю проверять
			var t = this;
			checker = setInterval(function(){		// постоянно слежу за ситуацией
				t.check_for_update();				// проверяю
			}, 250);								// делаю это 4 раза в секунду
		};
		this.check_for_update = function(a){			// сама проверочка
			var player = Mu.blocks.di.repo.player.getTrack();
			this.e_status(player);					// изменяю текущий статус проигрывателя
			if (this.status[0]){	// узнаю, есть ли что-то
				if (this.last_played != player.id) { // нужно ли что-то менять
					this.output_status('loading', 'Загрузка…', 'Подождите, пожалуйста', 'Производится поиск и подготовка необходимых данных к выводу…<br><br>Наберитесь терпения, пожалуйста, скоро всё будет.<br>А если не будет, то ваc об этом оповестят, поверьте ;)');
					if (!player.lyricsAvailable)	// текст к песне отсутствует, об этом известно заранее
						this.output_lyric('Текст к песне отстутствует.\n\nЛибо его просто нет в базе Яндекс.Музыки.\nКстати, если текст всё таки существует, обратитесь в службу поддержки Яндекс.Музыки, это и в их интересах.\n\nНа сколько мне известно, текст песен они берут со сторноних сервисов, с которыми у них налажено сотрудничество.', 'absent');
					else
						this.output_lyric('Подождите, пожалуйста…\n\nПохоже, что текст к песне существует, но нужно время, чтобы заполучить его.\nПри хорошой скорости интернета, это должно произойти быстро.\nЕсли этот текст вы видите довольно таки продолжительно время, это может значить, что ваше устройство потеряло доступ к интернету.\nЛибо просто упали сервера Яндекс, такое тоже бывает.', 'loading');
					if (this.status[1] == 2 || a)
						this.output_tracks_main_info(player); // вывожу уже известную информацию
				} else {							// не нужно ничего менять

				}
					if (player.liked)
						$('.YaRD__like').addClass('m--liked');
					else
						$('.YaRD__like').removeClass('m--liked');
			} else {								// нет ничего, не буду даже пытаться
				this.output_status('failed' ,'Ошибка', 'Почти катастрофа', 'Что-то пошло не так, как должно…<br><br>Такое бывает, не пугайтесь.<br>Возможно ваше устройстов потеряло доступ к интернету, проверьте интернет-соединение.<br>Если причина не в этом, то это может происходить по причине падения серверов Яндекс, такое тоже случается :)');
				console.log('YaRD •--• Плеер не запущен. фатальная ошибка. проверьте интернет соединение');
			}
		};
		this.output_status = function(a, b, c, d){
			$('body').attr('data-yard-data-status', a);
			if (b){
				$('.t--YaRD_output_status__name').html(b);
				$('.t--YaRD_output_status__second_name').html(c);
				$('.t--YaRD_output_status__descrition').html(d);
			}
		};
		this.output_tracks_main_info = function(player){ // вывод известной инфы
			this.last_played = player.id;
			this.output_status('loaded');
				window.postMessage({
					need_to_know: this.last_played,
					source: 'YaRD'
				}, '*');
			this.output__player('track_name', player.title);
			this.output__player('track_version', player.version);
			if (player.format && player.format.codec)
				this.output__player('file_format', player.format.codec);
			if (player.format && player.format.bitrate)
				this.output__player('file_bitrate', player['format']['bitrate']);
			this.output__player('track_src', player._ey);
			this.output__player('track_link', player._ey, ['link', 1]);
			this.output__player('track_id', player.id);
			this.output_all_artists(player.artists);
			this.output__player('main_artist_name', player.artists[0].name)
			if ((player.artists[0].name == "Linkin Park") || (player.artists[0].name == "Fort Minor") || (player.artists[0].name == "Hollywood Undead"))
				$('body').attr('data-yard-favorite-artist', player.artists[0].name);
			else
				$('body').removeAttr('data-yard-favorite-artist');
			var all_artists = '';
			this.get_artist_val(player.artists, function(i, name, link, img, fail){
				if (fail)
					return false;
				all_artists += name + ', ';
			});
			this.output__player('artist_name', all_artists.slice(0, -2));
			if (!player.artists[0].various)
				this.output__player('artist_link', player.artists[0].id, ['link', 1, '//music.yandex.ru/artist/']);
			else
				this.output__player('artist_link', '', ['link', 1]);
			if (player.artists[0].cover && player.artists[0].cover.uri)
				this.output__player('artist_cover', player.artists[0].cover.uri, ['img', 1, '100']);
			else
				this.output__player('artist_cover', player.albums[0].coverUri, ['img', 1, '600']);
			this.output__player('album_name', player.albums[0].title);
			this.output__player('album_track_count', player.albums[0].trackCount);
			this.output__player('album_version', player.albums[0].version);
			this.output__player('album_year', player.albums[0].year);
			this.output__player('album_genre', player.albums[0].genre);
			this.output__player('album_cover', player.albums[0].coverUri, ['img', 1, '600', '//']);
			this.output__player('album_cover_bg', player.albums[0].coverUri, ['img', 0, '600', '//']);
			this.output__player('album_cover_bg_1000', player.albums[0].coverUri, ['img', 0, '1000', '//']);
		};
		this.output_lyric = function(lyrics, status){
			$('body').attr('data-yard-lyric-status', status);
			this.output__player('lyric', '<p>'+ lyrics.replace(/[\n]/g, '</p><p>').replace(/<p><\/p>/g, '<p class="YaRD__lyric_separator"></p>') +'</p>');
		};
		this.output__player = function(el, param, type, re){ // шаблон вывода с проверкой
			var el_class = '.t--YaRD_output__'+ el,
				el_block_class = '.t--YaRD_output_block__'+ el,
				el_error_class = 't--YaRD_output_error';
			if (!type){
				if (param){ 							// есть информация для вывода
					$(el_class).html(param).scrollTop(0);// вывожу её
					$(el_block_class).removeClass(el_error_class);
					return true;						// ради прикола, вдруг буду ещё где-то проверять
				} else {								// нет ифны для вывода
					if (!re) {					// нужно ли совершить ещё одну попытку. а что, а вдруг?
						var t = this;
						setTimeout(function(){			// собираюсь выводить ещё раз
							t.output__player(el, param, 0, 1); // отправляю запрос на повторение
						}, 500);						// и секунды после провала не прошло, как я совершаю очередную попытку
					} else {							// если снова пытаться не нужно, то вообще всё просто
						$(el_block_class).addClass(el_error_class); // проблема, чуваки, я предупредил
						$(el_class).html('Данные отсутствуют');
						// console.error('YaRD •--• Ошибка при выводе кое-какой информации | Данные отсутствуют •--• ' + el);
						return false;					// если будет ещё одна проверка, "чтоб ты знал"
					}
				}
			} else {
				if (param){								// сомнительная проверка
					var before = '',					// подготавливаю ссылку для вставки
						output = '';
					$(el_block_class).removeClass(el_error_class);
					if (type[0] == 'img'){				// если вывожу картинку
						if (type[3])					// если есть что добавить
							before = type[3];			// не верю, что такое будет, но зато так универсальние
						output += before + param.replace('%%', type[2] +'x'+ type[2]); // ссылка готова
						if (type[1])					// если нужно выводить для img
							$(el_class).attr('src', output);
						else							// если нужно вставлять в блок как фон
							$(el_class).css('background-image', 'url('+ output +')');
					} else if (type[0] = 'link'){		// если вывожу ссылку
						if (type[2])					// если есть что добавить
							before = type[2];			// добавляю
						output += before + param;		// ссылка готова
						if (type[1]){					// если выводится в a
							$(el_class).attr('href', output); // записываю всё в href, ссылка готова
							if (param == '')
								$(el_class).removeAttr('href');
						} else {						// если вывожу ссылку как текст (на момент написания кода, не вижу смысла в этом. "ну а что, а вдруг?")
							$(el_class).html(output);	// вывожу как текст
						}
					} else {							// если мне нужна не картинка и не ссылка, то я не знаю, что хочу, поэтому в сообщаю юзеру в консольке об этом
						$(el_block_class).addClass('.t--YaRD_output_warning');
						console.error('YaRD •--• Хочу что-то вывести, но сам не могу понять, что хочу');
					}
				} else {								// передал какую-то дичь. не могу понять, откуда и что брать
					$(el_block_class).addClass(el_error_class); // раз произошла подобная дичь, то нужно как-то это отразить визуально
					console.error('YaRD •--• Пытаюсь вывести то, чего нет. Во какой я молодец, стараюсь дать максимум инфы для юзера');
					if (type[0] == 'img'){				// если вывожу картинку
						if (type[1]){					// если нужно выводить для img
							$(el_class).removeAttr('src');
							$(el_class).attr('src', 'chrome-extension://iipdlolanhldhhdjaiebciofkiejnold/img/256.png');
						} else {						// если нужно вставлять в блок как фон
							$(el_class).css('background-image', '');
							$(el_class).css('background-image', 'url('+ 'chrome-extension://iipdlolanhldhhdjaiebciofkiejnold/img/256.png' +')');
						}
					} else if (type[0] = 'link') {
						if (type[1])					// если выводится в a
							$(el_class).removeAttr('href'); // записываю всё в href, ссылка готова
						else							// если вывожу ссылку как текст (на момент написания кода, не вижу смысла в этом. "ну а что, а вдруг?")
							$(el_class).html('music.yandex.ru');	// вывожу как текст
					}
				}
			}
		};
		this.output_all_albums = function(arr){		// а эта функция типа выводит по шаблону все альбомы, в которых встречается играющая песня
			var class_prefix = '.t--YaRD_in_albums__',
				class_wrap = class_prefix+ 'wrap',
				class_block = class_prefix+ 'block',
				class_error = ['t--YaRD_output_error', 't--YaRD_output_warning'];
			if (arr && arr.length){									// если всё по плану, есть что выводить
				$(class_wrap).removeClass(class_error[0]); // есть что показать, удаляю класс отвечающий за скрытие у блока обвёртки
				if (!$(class_block).length)				// шаблон отстутствует
					return false;						// нет шаблона, не нужно стараться
				for (var i in arr){						// пробегаю по всем имеющимся альбомам
					var el = $(class_wrap).find(class_block).eq(i);
					if (!el.length){					// если нет нужного блока
						var clone = $(class_block)[0];	// создаю копию по шаблону
						clone = $(clone).clone();
						$(class_wrap).append(clone);	// вставляю его во все обвёртки
						el = $(class_wrap).find(class_block).eq(i); // переключаюсь на только что созданный элемент
						delete clone;					// удаляю клона
					}									// продолжаю работать, заполняю блоки содержимым
					$(el).removeClass(class_error[1]);	// обновляю статус элемента от последствий возможных предыдущих провалов
					this.output__all_val([el, class_prefix+ 'album_name', class_error], arr[i].title);
					var s = this.output__all_val([el, class_prefix+ 'album_version', class_error], arr[i].version);
					if (s) $(el).addClass('t--version');
					else $(el).removeClass('t--version');
					$(el).find(class_prefix+ 'album_link').attr('href', this.get_link(arr[i].id, 'music.yandex.ru/album/'));
					this.output__all_val([el, class_prefix+ 'album_track_count', class_error], arr[i].trackCount);
					this.output__all_val([el, class_prefix+ 'album_year', class_error], arr[i].year);
					this.output__all_val([el, class_prefix+ 'album_genre', class_error], arr[i].genre);
					this.output__all_val([el, class_prefix+ 'album_cover', class_error], this.get_link(arr[i].coverUri, 0, 100), 1);

					$(el).find(class_prefix+'artist_block:gt(0)').remove();
					this.get_artist_val(arr[i].artists, function(i, name, link, img, fail){
						if (fail){
							$(el).find(class_prefix+'artist_wrap').addClass(class_error[1]);
							console.error('YaRD •--• Не получилось вывести данные об исполнителе(ях) альбома: '+ arr[i].title);
							return false;
						}
						var sub_el = $(el).find(class_prefix+'artist_block').eq(i);
						if (!sub_el.length){					// если нет нужного блока
							var clone = $(class_prefix+'artist_block')[0];	// создаю копию по шаблону
							clone = $(clone).clone();
							$(el).find(class_prefix+'artist_wrap').append(clone); // вставляю его во все обвёртки
							sub_el = $(el).find(class_prefix+'artist_block').eq(i); // переключаюсь на только что созданный элемент
							delete clone;					// удаляю клона
						}			
						$(el).find(class_prefix+'artist_wrap').removeClass(class_error[1]);
						$(sub_el).find(class_prefix+'artist_name').html(name);
						if (link)
							$(sub_el).find(class_prefix+'artist_link').attr('href', link);
						else
							$(sub_el).find(class_prefix+'artist_link').removeAttr('href');
						$(sub_el).find(class_prefix+'artist_cover').attr('src', img);
					});
				}
				$(class_wrap).find(class_block+':gt('+ (arr.length-1) +')').remove(); // удаляю лишние блоки, если таковые имеются
			} else {									// мало вероятно, что такое произойдёт при правильном запросе
				$(class_wrap).addClass(class_error[0]);
				console.error('YaRD •--• Кажется, массив со списком всех альбомов отсутствует');
			}
		};
		this.output_track_versions = function(arr){		// а эта функция типа выводит по шаблону все альбомы, в которых встречается играющая песня
			var class_prefix = '.t--YaRD_track_versions__',
				class_wrap = class_prefix+ 'wrap',
				class_type_block = class_prefix+ 'type',
				class_block = class_prefix+ 'block',
				class_error = ['t--YaRD_output_error', 't--YaRD_output_warning'];
			var type = ["another", "instrumental", "live", "remix"];
			if (arr && (arr[type[0]].length || arr[type[1]].length || arr[type[2]].length || arr[type[3]].length)){// если всё по плану, есть что выводить	
				$(class_wrap).removeClass(class_error[0]); // есть что показать, удаляю класс отвечающий за скрытие у блока обвёртки
				for (var t in type){
					if (!$(class_type_block +' '+class_block).length)// шаблон отстутствует
						return false;						// нет шаблона, не нужно стараться
					var arr_t = arr[type[t]];
					if (arr[type[t]].length)
						$('[data-yard-version-name="'+ type[t] +'"]').removeClass(class_error[0]);
					else
						$('[data-yard-version-name="'+ type[t] +'"]').addClass(class_error[0]);
					for (var i in arr_t){			// пробегаю по всем имеющимся альбомам
						var el = $('[data-yard-version-name="'+ type[t] +'"]').find(class_block).eq(i);
						if (!el.length){					// если нет нужного блока
							var clone = $(class_block)[0];	// создаю копию по шаблону
							clone = $(clone).clone();
							$('[data-yard-version-name="'+ type[t] +'"]').append(clone);	// вставляю его во все обвёртки
							el = $('[data-yard-version-name="'+ type[t] +'"]').find(class_block).eq(i); // переключаюсь на только что созданный элемент
							delete clone;					// удаляю клона
						}									// продолжаю работать, заполняю блоки содержимым
						$(el).removeClass(class_error[1]);	// обновляю статус элемента от последствий возможных предыдущих провалов
						this.output__all_val([el, class_prefix+ 'album_name', class_error], arr_t[i].title);
						var s = this.output__all_val([el, class_prefix+ 'album_version', class_error], arr_t[i].version);
						if (s) $(el).addClass('t--version');
						else $(el).removeClass('t--version');
						$(el).find(class_prefix+ 'album_link').attr('href', this.get_link(arr_t[i].id, 'music.yandex.ru/album/'+ arr_t[i].albums[0].id +'/track/'));
						this.output__all_val([el, class_prefix+ 'album_track_count', class_error], arr_t[i].albums[0].trackCount);
						this.output__all_val([el, class_prefix+ 'album_year', class_error], arr_t[i].albums[0].year);
						this.output__all_val([el, class_prefix+ 'album_genre', class_error], arr_t[i].albums[0].genre);
						this.output__all_val([el, class_prefix+ 'album_cover', class_error], this.get_link(arr_t[i].albums[0].coverUri, 0, 100), 1);

						$(el).find(class_prefix+'artist_block:gt(0)').remove();
						this.get_artist_val(arr_t[i].artists, function(i, name, link, img, fail){
							if (fail){
								$(el).find(class_prefix+'artist_wrap').addClass(class_error[1]);
								console.error('YaRD •--• Не получилось вывести данные об исполнителе(ях) альбома: '+ arr_t[i].title);
								return false;
							}
							var sub_el = $(el).find(class_prefix+'artist_block').eq(i);
							if (!sub_el.length){					// если нет нужного блока
								var clone = $(class_prefix+'artist_block')[0];	// создаю копию по шаблону
								clone = $(clone).clone();
								$(el).find(class_prefix+'artist_wrap').append(clone); // вставляю его во все обвёртки
								sub_el = $(el).find(class_prefix+'artist_block').eq(i); // переключаюсь на только что созданный элемент
								delete clone;					// удаляю клона
							}			
							$(el).find(class_prefix+'artist_wrap').removeClass(class_error[1]);
							$(sub_el).find(class_prefix+'artist_name').html(name);
							if (link)
								$(sub_el).find(class_prefix+'artist_link').attr('href', link);
							else
								$(sub_el).find(class_prefix+'artist_link').removeAttr('href');
							$(sub_el).find(class_prefix+'artist_cover').attr('src', img);
						});
					}
					$('[data-yard-version-name="'+ type[t] +'"]').find(class_block+':gt('+ (arr_t.length-1) +')').remove(); // удаляю лишние блоки, если таковые имеются
				}
			} else {									// мало вероятно, что такое произойдёт при правильном запросе
				$(class_wrap).addClass(class_error[0]);
				// console.error('YaRD •--• Кажется, массив со списком всех альбомов отсутствует');
			}
		};
		this.output__all_val = function(el, val, isImg){
			if (val) {
				if (isImg){								// требовалось вывести картинку
					$(el[0]).find(el[1]).attr('src', val);
				} else {
					$(el[0]).find(el[1]).html(val); 		// требовалось вывести текст
				}
				$(el[0]).find(el[1]).removeClass(el[2][0]); // предыдущие провалы - в прошлом
				$(el[0]).removeClass(el[2][1]);
				return true;
			} else {									// проблема, провал, чуваки, я предупредил
				if (isImg)
					$(el[0]).find(el[1]).removeAttr('src');
				else
					$(el[0]).find(el[1]).html('Данные отсутствуют');
				$(el[0]).find(el[1]).addClass(el[2][0]);
				$(el[0]).addClass(el[2][1]);
				// console.error('YaRD •--• Не получилось вывести кое-какую информацию');
				return false;
			}
		};
		this.output_all_artists = function(arr){
			var class_prefix = '.t--YaRD_all_artists__',
				class_wrap = class_prefix+ 'wrap',
				class_output = class_prefix+ 'output',
				class_block = class_prefix+ 'block',
				class_error = ['t--YaRD_output_error', 't--YaRD_output_warning'];
			if (arr && arr.length){
				$(class_wrap).removeClass(class_error[0]);
				if (!$(class_block).length)				// шаблон отстутствует
					return false;						// нет шаблона, не нужно стараться
				var t = this;							// ллайфхак
				this.get_artist_val(arr, function(i, name, link, img, fail){ // пробегаю по всем имеющимся артистам
					if (fail)
						return false;
					var el = $(class_wrap).find(class_block).eq(i);
					if (!el.length){					// если нет нужного блока
						var clone = $(class_block)[0];	// создаю копию по шаблону
						clone = $(clone).clone();
						$(class_output).append(clone);	// вставляю его во все обвёртки
						el = $(class_wrap).find(class_block).eq(i); // переключаюсь на только что созданный элемент
						delete clone;					// удаляю клона
					}									// продолжаю работать, заполняю блоки содержимым
					$(el).removeClass(class_error[1]);	// обновляю статус элемента от последствий возможных предыдущих провалов
					t.output__all_val([el, class_prefix+ 'artist_name', class_error], name);
					if (link)
						$(el).find(class_prefix+ 'artist_link').attr('href', link);
					else
						$(sub_el).find(class_prefix+'artist_link').removeAttr('href');
					if (arr[i].cover)
						t.output__all_val([el, class_prefix+ 'artist_cover', class_error], img, 1);
					else
						t.output__all_val([el, class_prefix+ 'artist_cover', class_error], 'chrome-extension://iipdlolanhldhhdjaiebciofkiejnold/img/256.png', 1);
				});
				$(class_wrap).find(class_block+':gt('+ (arr.length-1) +')').remove(); // удаляю лишние блоки, если таковые имеются
			} else {
				$(class_wrap).addClass(class_error[0]);
				console.error('YaRD •--• Кажется, массив со списком всех исполнителей отсутствует');
			}
		};
		this.get_link = function(val, before, size){
			if (val){
				if (!before) before = '';
				if (size) val = val.replace('%%', size +'x'+ size);
				return '//'+ before + val;
			} else {
				if (size)
					return 'chrome-extension://iipdlolanhldhhdjaiebciofkiejnold/img/256.png';
				else
					return '//magomedov-said.ru';
			}
		};					// если ты читаешь это, будь добр, напиши на это мыло -> linpark1999@gmail.com -> письмо, тема письма: "твой читатель", и, желательно, в тексте письма где-нибудь вписать: "Говнокод расширения YaRD - прочитан. не знаю, как браузер, а вот глаза расширились у меня, от говнокода.". спасибо тебе, огромное. ты герой, правда зря убил время, читая это.
		this.get_artist_val = function(arr, callback){
			var cover;
			if (arr && arr.length){
				for (var i in arr){
					if (arr[i].cover && arr[i].cover.uri){
						cover = this.get_link(arr[i].cover.uri, 0, 100);
					} else {
						cover = 'chrome-extension://iipdlolanhldhhdjaiebciofkiejnold/img/256.png';
					}
					if (arr[i].various)
						callback(i, arr[i].name, false, cover);
					else
						callback(i, arr[i].name, this.get_link(arr[i].id, 'music.yandex.ru/artist/'), cover);
				}
			} else {
				cover = YaRD_class.ico || '';
				callback(0, YaRD__class.name, YaRD__class.link, cover, 1);
				return false;
			}
		};
		this.output_all_videos = function(arr){
			var class_prefix = '.t--YaRD_all_videos__',
				class_wrap = class_prefix+ 'wrap',
				class_output = class_prefix+ 'output',
				class_block = class_prefix+ 'block',
				class_error = ['t--YaRD_output_error', 't--YaRD_output_warning'];
			if (arr && arr.length){
				$(class_wrap).removeClass(class_error[0]);
				if (!$(class_block).length)				// шаблон отстутствует
					return false;						// нет шаблона, не нужно стараться
				var t = this;							// лайфхак
				this.video_list = [];
				this.get_video_val(arr, function(i, name, link, embed, img, fail){ // пробегаю по всем имеющимся видео
					if (fail)
						return false;
					var el = $(class_wrap).find(class_block).eq(i);
					if (!el.length){					// если нет нужного блока
						var clone = $(class_block)[0];	// создаю копию по шаблону
						clone = $(clone).clone();
						$(class_output).append(clone);	// вставляю его во все обвёртки
						el = $(class_wrap).find(class_block).eq(i); // переключаюсь на только что созданный элемент
						delete clone;					// удаляю клона
					}									// продолжаю работать, заполняю блоки содержимым
					$(el).removeClass(class_error[1]);	// обновляю статус элемента от последствий возможных предыдущих провалов
					$(el).attr('data-yard-video-index', i);
					t.output__all_val([el, class_prefix+ 'video_name', class_error], name);
					t.output__all_val([el, class_prefix+ 'video_embed', class_error], embed.replace('autoplay=1', 'autoplay=0'));
					t.video_list[i] = embed;
					if (link)
						$(el).find(class_prefix+ 'video_link').attr('href', link);
					else
						$(sub_el).find(class_prefix+'video_link').removeAttr('href');
					if (arr[i].cover)
						t.output__all_val([el, class_prefix+ 'video_cover', class_error], img, 1);
				});
				$(class_wrap).find(class_block+':gt('+ (arr.length-1) +')').remove(); // удаляю лишние блоки, если таковые имеются
			} else {
				$(class_wrap).addClass(class_error[0]);
				// console.error('YaRD •--• Кажется, массив со списком видеозаписей отсутствует');
			}
		};
		this.get_video_val = function(arr, callback){
			var cover;
			if (arr){
				for (var i in arr){
					if (arr[i].cover && arr[i].cover.uri){
						cover = this.get_link(arr[i].cover.uri, 0, 100);
					} else {
						cover = 'chrome-extension://iipdlolanhldhhdjaiebciofkiejnold/img/256.png';
					}
					callback(i, arr[i].title, arr[i].url, arr[i].embed, arr[i].cover);
				}
			} else {
				callback(0, 0, 0, 0, 0, 1);
				return false;
			}
		};

		// ----------------------------------------------------------------------------------------ScreenSaver
			// ScreenSaver by Magomedov Said, 2016
		var getRandomInt = function(min, max) {
				return Math.floor(Math.random() * (max - min)) + min;
			},
			screen_saver_live;
		this.screen_saver = function(){
			var scale = [getRandomInt(100, 120), 0],
				position = [getRandomInt(0, 100), getRandomInt(0, 100)];
				scale[1] = scale[0];
				if ($(window).width() > $(window).height()){
					scale[0] += '%';
					scale[1] = 'auto';
				} else {
					scale[0] = 'auto';
					scale[1] += '%';
				}
			$('.YaRD_screen_saver').css({
				'background-position': position[0] +'% '+ position[1] +'%',
				'background-size': scale[0] +' '+ scale[1]
			});
		};
		this.start_screen_saver = function(live, stop, static){
			if(stop){
				clearInterval(screen_saver_live);
				$('body').removeClass('YaRD_screen_saver_animated')
						.removeClass('YaRD_screen_saver_preview_extended');
				$('.YaRD_screen_saver__top .m--toggle_wrap')
						.removeClass('m--subchecked')
						.removeClass('m--checked');
				$('.YaRD_screen_saver').css({
					'background-position': '',
					'background-size': ''
				});
				if (!live){
					$('body').removeClass('YaRD_screen_saver_opened');
				}
				return true;
			}
			if (!live && !static){
				this.screen_saver();
			} else {
				$('body').addClass('YaRD_screen_saver_opened');
				if (static)
					return true;
				this.screen_saver();
				var t = this;
				$('body').addClass('YaRD_screen_saver_animated')
						.removeClass('YaRD_screen_saver_blur_preview');
				$('.YaRD_screen_saver__top .m--toggle_wrap').removeClass('m--blur_checked');
				screen_saver_live = setInterval(function(){
					t.screen_saver();
				},8010);
			}
		};
	}
}
var YaRD = new YaRD__class.init();
$(document).ready(function(){
	// var checker = setInterval(function(){
	// 		var s = YaRD.e_status(Mu.blocks.di.repo.player.getTrack());
	// 		if (s)
	// 			clearInterval(checker);
	// 	}, 250);
var checker = setInterval(function(){
var s
if (Mu.blocks.di.repo.player.getTrack){
	s = YaRD.e_status(Mu.blocks.di.repo.player.getTrack());
} else if (Mu.blocks.di.repo.player.getTrack){
	s = YaRD.e_status(Mu.blocks.di.repo.player.getTrack());
}
if (s){
	clearInterval(checker);
	console.log('YaRD •--• Расширение готово работать');
	// --------------------------------------------------------------------------------------------- finished
	var button = '.YaRD_download_button';
	$(button).click(function(){						// кто-то нажал на кнопку. супер-расширение уже спешит на помощь
		YaRD.download(1, function(status, name){ // пытаюсь скачать файл. [0] = данные о треке; [1] = ответ: [1][0] = 0 - песня не скачалась, 1 - всё чётко; [1][1] = название скачиваемой песни
			if(status){								// скачивается
				console.info('YaRD •--• Скачивается песня: ' + name);
				$(button).removeClass('m--finished').addClass('m--visible'); // показываю, что что-то произошло, скачивание началось
				// setTimeout(function(){				// убираю оповещение о начале скачки, юзеру должно хватить данного времени, чтобы понять, что я хотел сказать. а если он не успел, то он слишком глуп
				// 	$(button).removeAttr('data-yard-wait');
				// }, 3000);
			} else {// решил не скачивать песню
				console.error('YaRD •--• Что-то случилось, песня не скачалась :(');
			}
		});
	});
	// ------------------------------------------------------------------------------------------------------
	// ------------------------------------------------------------------------------------------------------
	$('.YaRD_lyrics_button').click(function(){ 		// потребовался текст песни
		if ( $('body[data-yard-lyrics]').length ){ 	// окно открыто
				// проверяю на необходимость обновления содержимого
			$('body').removeAttr('data-yard-lyrics'); // скрываю скрываю его
			YaRD.start_updating(1);
		} else {									// если окно не открыто
			$('body').attr('data-yard-lyrics', ''); // показываю окно

			YaRD.start_updating();	
		}
	});												// скрываю блок с лирикой по просьбе юзера
	$('.YaRD_lyrics__close_button, .logo__service, .head__stations').click(function(){
		$('body').removeAttr('data-yard-lyrics');
		YaRD.start_updating(1);
	});


	window.postMessage({							// проверяю, имеются ли новости, объявления
		news:true,
		source: 'YaRD'
	}, '*');
	// чекаю входящие - получаю данные о треке и текст к нему - здесь же и вызов функции вывода лирики
	window.addEventListener('message', function(event){
		var message = event.data;
		if (message.source == 'YaRD_res'){ // если сообщение отправлено мне
			if (message.res){
				YaRD.output_all_albums(message.res.alsoInAlbums); // я человек простой, получил инфу - расказываю о ней
				YaRD.output_all_videos(message.res.video);
				YaRD.output_track_versions(message.res.otherVersions);
				if (message.res.lyric.length)		// текст к песне есть, вывожу его
					YaRD.output_lyric(message.res.lyric[0].fullLyrics, 'loaded');
			} else if (message.news_res){
				var m = message.news_res;
				if (m != 'fail'){
					if (m.title)
						$('.t--YaRD_output__news_title').html(m.title);
					else
						$('.t--YaRD_output__news_title_block').remove();
					if (m.subtitle)
						$('.t--YaRD_output__news_subtitle').html(m.subtitle);
					if (m.text)
						$('.t--YaRD_output__news_text').html(m.text);
					else
						$('.YaRD__news_subtext_border').remove();
					if (m.subtext)
						$('.t--YaRD_output__news_subtext').html(m.subtext);
					else
						$('.t--YaRD_output__news_subtext').remove();

					$('.t--YaRD_output__news_block').addClass('m--visible');
				}
			} else if (message.download_res){
				// if (message.download_res != 'finished'){
				// 	$('.player-controls__play').click();	// очередной костыль
				// }
				// else{
					if (Mu.blocks.di.repo.player.isPlaying() == (message.download_play_status - 1) && Mu.authData.user.uid == 0)
						$('.player-controls__play').click();
					$(button).addClass('m--finished');
					setTimeout(function(){
						$(button).removeClass('m--visible');
					},2000);
				// }
			}
		}
	});

	// управление плеером: приостановить/запустить; лайк и дизлайк/пропустить ---------------------- finished
	$('.YaRD__dislike').click(function(){
		$('.like_action_dislike').click();
	});
	$('.YaRD__play_pause').click(function(){
		$('.player-controls__play').click();
	});
	$('.YaRD__like').click(function(){
		$('.like_action_like').click();
	});
	// $('.like_action_like').click(function(){
	// 	$('.YaRD__like').toggleClass('m--liked');
	// });

	// резервная конпка скачивания ----------------------------------------------------------------- finished
	$('.YaRD_lyrics__download').click(function(){
		YaRD.download(2, function(status, name){
			if(status){								// скачивается
				console.log('YaRD •--• Скачивается песня: ' + name);
				$('.YaRD_lyrics__download').addClass('m--downloading'); // показываю, что что-то произошло, скачивание началось
				setTimeout(function(){				// убираю оповещение о начале скачки, юзеру должно хватить данного времени, чтобы понять, что я хотел сказать. а если он не успел, то он слишком глуп
					$('.YaRD_lyrics__download').removeClass('m--downloading');
				}, 5000);
			} else {								// решил не скачивать песню
				console.error('YaRD •--• Что-то случилось, песня не скачалась :(');
			}
		});
	});

	// Переключение между разделами ---------------------------------------------------------------- finished
	$('[data-yard-goto]').click(function(){
		var to = $(this).attr('data-yard-goto'),
			to_index = $('[data-yard-block="'+ to +'"]').index();
			$('[data-yard-goto]').removeClass('m--active');
			$(this).addClass('m--active');
			$('.YaRD_lyrics .m--ex_active').removeClass('m--ex_active');
			$('[data-yard-block-status="active"]').addClass('m--ex_active');
		$('[data-yard-block]').each(function(index, el) {
			if(index < to_index){
				$(this).attr('data-yard-block-status', 'prev');
			} else if (index == to_index) {
				$(this).attr('data-yard-block-status', 'active');
			} else {
				$(this).attr('data-yard-block-status', 'next');
			}
		});
	});

	// Параллакс шапкок разделов -------------------------------------------------------------------- finished
	$('.YaRD_lyrics__block').scroll(function(){
		var this_scroll_top = $(this).scrollTop(),
			children = $(this).find('.YaRD_lyrics__header'),
			children_outer_height = $(children).outerHeight();
		if(this_scroll_top > children_outer_height){
			$(children).css('transform', 'translateY(50%)');
		} else {
			$(children).css('transform', 'translateY('+ (this_scroll_top*50)/children_outer_height +'%)');
		}
	});
	// ------------------------------------------------------------------------------------------------------
	$('html').on('click','[data-yard-video-index]', function(){
		$('body').attr('data-yard-video-status', 'open');
		console.log('---------');
		$('.YaRD_video__embed').html(YaRD.video_list[ $(this).attr('data-yard-video-index') ]);
		Mu.blocks.di.repo.flow.pause();
	})
	.on('click','.YaRD_video__close', function(){
		$('body').removeAttr('data-yard-video-status');
		$('.YaRD_video__embed').html('');
		Mu.blocks.di.repo.flow.resume();
	});
	// -----------------------------------------------------------------------------------------Screen Saver
	startTime();
	$('.YaRD_screen_saver__button').click(function(){
		YaRD.start_screen_saver(1, 0, 1);				// не сам доганяю, как я это написал, что оно и работает как надо, так и разные комбинации подаваемых параметров в функцию работают верно
	});
	$('.YaRD_screen_saver__top_control.m--close').click(function(){
		YaRD.start_screen_saver(0, 1);					// сложно так взять и сказать, что у меня значат 0 и 1 здесь, false и true - это точно, но без кода самой функции - это что-то дичайшее
		$('.YaRD_screen_saver__top .m--toggle_wrap').removeClass('m--checked');
	});
	$('.YaRD_screen_saver__top .m--toggle_wrap')		// ЕЩВЩ (TODO): переписать в отдельную функцию, чтобы не поторять говнокод для разных кнопок 
	.mousedown(function(e){
		YaRD.screen_saver_toggle = 1;					// мышь нажата
		if (e.which == 3)								// о, правой кнопкой мыши кликнули. прикол!
			YaRD.screen_saver_toggle_right_click = 1;
		if (e.which == 2)
			YaRD.screen_saver_toggle_scroll_click = 1;
		var t = this,
			s = 0;
		function f(){									// определяюсь, что был клик, а не зажатике кнопки мыши, делаю, что нужно...
			if (!YaRD.screen_saver_toggle && !s){		// мышь уже не нажата и событие клика ещё не ловилось
				s = 1;									// поймали событие клика
				if (e.which == 3){							// правый клик
					$(t).toggleClass('m--subchecked');	// управляю состоянием. скрытие элементов
					if ($(t).hasClass('m--subchecked')){ // можно было бы исльзовать тоже toggleClass, но для надёжности делаю так
						$('body').addClass('YaRD_screen_saver_preview_extended')
								.removeClass('YaRD_screen_saver_blur_preview');
						$(t).removeClass('m--blur_checked');
					} else {
						$('body').removeClass('YaRD_screen_saver_preview_extended');
					}
					return false;						// использовалась правая кнопка мыши, контексное меню не вывожу, за обычный клик не считаю (дальше)
				}
				if (e.which == 2){
					$(t).toggleClass('m--blur_checked');
					if ($(t).hasClass('m--blur_checked')){
						$('body').addClass('YaRD_screen_saver_blur_preview');
					} else {
						$('body').removeClass('YaRD_screen_saver_blur_preview');
					}
					YaRD.start_screen_saver(1, 1);
					return false;
				}
				$(t).toggleClass('m--checked');			// обычный клик. работаем, ребята
				if ($(t).hasClass('m--checked'))
					YaRD.start_screen_saver(1, 0, 0);	// видимо, это запускает движение фона
				else
					YaRD.start_screen_saver(1, 1);		// а это отменяет движение фона
			}
		}
		setTimeout(function(){f();},100);		// не знаю, возможно, что использование setTimeout в таких целях - костыль
		setTimeout(function(){f();},250);		// но это всё, на что догадался мой мозг
		setTimeout(function(){f();},350);		// я подумал минуты 2 и понял, что это лучший метод. я пытался придумать что-то другое, но не вышло.
		setTimeout(function(){
			if (YaRD.screen_saver_toggle){
				$('body').addClass('YaRD_screen_saver_preview');	// просмотр обложки, не размытой
				if (YaRD.screen_saver_toggle_right_click && !$(t).hasClass('m--checked')){	// при подвижном фоне, никаких просмотров всей обложки
					$('body').addClass('YaRD_screen_saver_contextmenu');
					$('body').addClass('YaRD_screen_saver_full_preview');					// скрываю лишние элементы
				}
			} else {							// для тормазов, которым нужно почти пол секунды, чтобы кликнуть
				f();							// о Боже, кликнули таки
			}
		},450);
		setTimeout(function(){
			if (YaRD.screen_saver_toggle)
				$('body').addClass('YaRD_screen_saver_full_preview');	// скрываю лишние элементы
		},1800);
		return false;
	})
	.mouseup(function(){
		screen_saver_out();
		return false;
	}).mouseleave(function(){
		screen_saver_out();
		return false;
	}).contextmenu(function(){
		return false;
	});
	function screen_saver_out(){				// ой, всё
		YaRD.screen_saver_toggle = 0;
		YaRD.screen_saver_toggle_right_click = 0;
		YaRD.screen_saver_toggle_scroll_click = 0;
		$('body').removeClass('YaRD_screen_saver_preview');
		$('body').removeClass('YaRD_screen_saver_full_preview');
		$('body').removeClass('YaRD_screen_saver_contextmenu');
		// $('body').removeClass('YaRD_screen_saver_preview_extended');
	}
}
}, 250);
});
var toggleFullScreen = function(a) {			// хрень, скопипастнутая с сайта документации Mozilla
	if (a === 1){
		if (!document.fullscreenElement &&    // alternative standard method
		!document.mozFullScreenElement && !document.webkitFullscreenElement)  // current working methods
			a = 0;
		else
			a = 2;
	}
	if (a == 2) {
		if (document.cancelFullScreen) {
			document.cancelFullScreen();
		} else if (document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		} else if (document.webkitCancelFullScreen) {
			document.webkitCancelFullScreen();
		}
	} else {
		if (document.documentElement.requestFullscreen) {
			document.documentElement.requestFullscreen();
		} else if (document.documentElement.mozRequestFullScreen) {
			document.documentElement.mozRequestFullScreen();
		} else if (document.documentElement.webkitRequestFullscreen) {
			document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
		}
	}
};

function startTime() {							// модифицированная версия чьего-то говнокода
	$('.YaRD_screen_saver__clock').addClass('m--started');
	var today = new Date(),
		h = today.getHours(),
		m = today.getMinutes(),
		s = today.getSeconds(),
		update_time = 60 - s;					// модификция - это я. я - 871ая (на момент написания коммента)
	m = checkTime(m);
	$('.YaRD_screen_saver__clock .h').html(h);
	$('.YaRD_screen_saver__clock .m').html(m);
	setTimeout(startTime, update_time*1000);	// модификация была здесь
}
function checkTime(i) {
	if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
	return i;
}