$.get(chrome.extension.getURL('js/injected.js'), 
	function(data) {
		var script = document.createElement("script");
		script.setAttribute("type", "text/javascript");
		script.innerHTML = data;
		document.getElementsByTagName("head")[0].appendChild(script);
	}
);

window.addEventListener('message', function(event) {
	// Only accept messages from the same frame
	if (event.source != window) {
		return;
	}

	var message = event.data;

	// Only accept messages that we know are ours
	if (message.source == 'YaRD') {
		if (message.lyrics){
			var link = 'https://music.yandex.ru/handlers/track.jsx?track='+message.lyrics;

			$.ajax(link)
				.done(function(res) {
					console.log("Нашёл инфу о треке " + res.track.title + " и текст этой самой песни:");
					console.log(res);
					if (res.lyric){
						window.postMessage({
							lyrics: res.lyric,
							track: [res.track.title, res.track.artists[0].name],
							full_info: res,
							source: 'YaRD_res'
						}, 'https://radio.yandex.ru/');
					}
				});
		}
	}
});